# Security Audit

Generated from repository evidence at 2026-08-19T23:11:43.628155+00:00. This is a static audit; runtime penetration testing was not performed because PHP/Composer dependencies are not installed in the sandbox.

## Findings

| ID | Severity | Category | Finding | Evidence | Priority |
|---|---|---|---|---|---|
| AUTH-001 | HIGH | Authentication | Custom session login is not synchronized with Laravel auth guard | `app/Http/Controllers/AuthController.php:58` | P0 |
| SEC-001 | CRITICAL | Security | Points credit endpoint lacks authentication and authorization | `routes/api.php:47` | P0 |
| SEC-002 | HIGH | Security / API | Conversion reporting endpoint lacks merchant authentication and idempotency | `routes/api.php:34` | P0 |
| SEC-003 | CRITICAL | Security | Default administrator password is committed in source | `database/seeders/AdminUserSeeder.php:17` | P0 |

The repository has CSRF middleware in the web group and file-session defaults, but authentication state is split between a custom session key and Laravel's guard. API reward mutation endpoints are not protected by an authentication/signature boundary. Default credentials are source-controlled. JWT, prompt-injection protection, LLM isolation, and tool permission isolation are **NOT MEASURABLE / NOT PRESENT** because no AI or JWT modules were discovered.
