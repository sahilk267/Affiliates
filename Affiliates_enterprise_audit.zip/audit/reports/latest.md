# Enterprise Audit Report

**Generated:** 2026-08-19T23:11:43.628155+00:00  
**Repository:** `sahilk267/Affiliates`  
**Commit:** `f23a894`

## Discovery proof

The dynamic scan indexed **187 files** in **65 directories** while excluding only `.git` internals and generated `audit/` outputs. It found **0 TypeScript**, **0 JavaScript**, **27 Markdown**, **2 JSON**, **0 automated test files**, and **0 Docker-related files**. The full per-file index is `audit/index.json`.

## Finding summary

| Severity | Count |
|---|---:|
| CRITICAL | 5 |
| HIGH | 7 |
| MEDIUM | 3 |
| INFO | 0 |

## Findings

| ID | Severity | Category | Title | Location | Priority |
|---|---|---|---|---|---|
| DB-001 | CRITICAL | Database | Migration dependency order prevents clean schema creation | `database/migrations/2025_01_25_100001_create_product_links_table.php:1` | P0 |
| DB-002 | CRITICAL | Database / Backend | Conversion runtime fields diverge from migration schema | `app/Conversion.php:19` | P0 |
| DB-003 | CRITICAL | Database / Backend | Commission payout fields diverge from migration schema | `app/Commission.php:18` | P0 |
| AUTH-001 | HIGH | Authentication | Custom session login is not synchronized with Laravel auth guard | `app/Http/Controllers/AuthController.php:58` | P0 |
| SEC-001 | CRITICAL | Security | Points credit endpoint lacks authentication and authorization | `routes/api.php:47` | P0 |
| SEC-002 | HIGH | Security / API | Conversion reporting endpoint lacks merchant authentication and idempotency | `routes/api.php:34` | P0 |
| BACK-001 | HIGH | Backend | Admin API test helpers bypass dependency injection | `app/Http/Controllers/AdminController.php:496` | P1 |
| SEC-003 | CRITICAL | Security | Default administrator password is committed in source | `database/seeders/AdminUserSeeder.php:17` | P0 |
| OPS-001 | HIGH | DevOps / Configuration | Environment template is missing | `README.md:95` | P1 |
| QA-001 | HIGH | Testing / DevOps | CI explicitly suppresses test failures | `.github/workflows/ci.yml:33` | P0 |
| QA-002 | HIGH | Testing | No automated test files are present | `phpunit.xml.dist:1` | P0 |
| API-001 | MEDIUM | API | No OpenAPI or machine-readable API contract is present | `routes/api.php:1` | P2 |
| BACK-002 | MEDIUM | Backend / Analytics | IP geolocation is hard-coded to India/Mumbai | `app/Http/Controllers/ApiController.php:531` | P2 |
| API-002 | HIGH | Attribution | Consumer purchase redirect does not create a tracked click | `app/Http/Controllers/ProductController.php:91` | P1 |
| DOC-001 | MEDIUM | Documentation | README references documentation files absent from checkout | `README.md:111` | P2 |

## Release conclusion

Release is blocked until the P0 issues are remediated and verified with a clean database initialization, authenticated API tests, consumer authentication tests, reward ledger tests, and CI that fails on test/migration errors.

See the sibling audit files for API, database, security, frontend, backend, AI, testing, documentation, code quality, architecture, dependencies, and release-readiness details.


## Calculated release score

**Release score:** **49.18/100** across 13 measurable categories, using the explicit control table in `audit/release-score.json`. Categories without repository/runtime evidence are recorded as **NOT MEASURABLE**, not converted into invented percentages.
