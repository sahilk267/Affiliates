# Backend Audit

The backend contains 7 controllers, 5 services, and 15 top-level domain models. Controllers use dependency injection in several places, but large controllers also contain direct Eloquent queries, duplicated product commission logic, and direct controller construction in admin API test helpers.

The principal backend risks are `DB-002`, `DB-003`, `BACK-001`, `BACK-002`, `API-002`, and non-transactional conversion orchestration. Complexity metrics are in `statistics.json`; they are static heuristics, not runtime profiled values.
