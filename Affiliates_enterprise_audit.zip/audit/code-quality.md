# Code Quality Audit

## Measured static metrics

- PHP method definitions scanned: 382
- Average cyclomatic complexity heuristic: 7.14
- Average maintainability index heuristic: 43.17
- Duplicate content groups: 0
- Duplicate filename groups: 10
- Dead-code candidates: 70 (heuristic; not proof of dead code)

The largest PHP files and highest-complexity files are listed in `statistics.json`. Runtime memory leaks, thread-level race conditions, and blocking I/O are **NOT MEASURABLE** from static source alone. The main maintainability concerns are oversized controllers, duplicated product commission logic, direct model queries, and stale documentation.
